
    const app = Vue.createApp({
    data() {
    return {
    superhero:[],
};
},
    methods: {
    mounted() {
    axios.get('https://cdn.jsdelivr.net/gh/rtomczak/superhero-api@0.3.0/api/all.json')
    .then(response => {
    this.superhero = response.data; // Récupérer les données des superhéros
})
    .catch(error => {
    console.log(error);
})
}
}
});
    app.mount('#app');


