
const app = Vue.createApp({
    data() {
    return {
        superhero:[],
        showPower:false,
        searchQuery: '',
        valeur_barre_int: 0,
        valeur_barre_force: 0,
        valeur_barre_vitesse: 0,
        filteredSuperheroeSuperpower: [],


    };
},
    computed: {
        filteredSuperhero() {
            return this.superhero.filter((hero) =>
                hero.name.toLowerCase().includes(this.searchQuery.toLowerCase()) //toLowerCase() evite le probléme de vide
            );
        },
        filteredSuperheroeSuperpower() {

        },

    },
    methods: {
        resetSearch() {
            this.searchQuery = '';
        },
        rechercherSuperpower(){
            this.filteredSuperheroeSuperpower = this.superhero.filter(hero => {
                const stats = hero.powerstats;
                return (
                    stats.intelligence >= this.valeur_barre_int &&
                    stats.strength >= this.valeur_barre_force &&
                    stats.speed >= this.valeur_barre_vitesse
                );

            })
        },
    },

    mounted() {
    axios.get('https://cdn.jsdelivr.net/gh/rtomczak/superhero-api@0.3.0/api/all.json')
    .then(response => {
    this.superhero = response.data; // Récupérer les données des superhéros
})
    .catch(error => {
    console.log("Erreur",error);
})
        fetch('navbar.html')
            .then(response => response.text())
            .then(data => {
                document.getElementById("navbar").innerHTML = data;
            })

    }
});
    app.mount('#app');


